//40223026
//hadiehzahra habibi


#include <stdio.h>
#include <math.h>

void solver(float a , float b , float c , float* x1 , float* x2);

int main()
{
    float a , b , c ;
    float x1 , x2 ;
    printf("enter a,b,c:\n");
    scanf("%f%f%f",&a,&b,&c);

    if(a == 0 && b == 0)
        printf("the numbers you entered are incorrect.");

    else if ((b * b) - (4 * a * c) < 0)
        printf("this equation has no real roots!");

    else
    {
        solver(a , b , c , &x1 , &x2) ;

        if(x1 != x2)
            printf("this equation has two real roots:\n x1 = %f , x2 = %f" , x1 , x2);

        else if (x1 == x2)
            printf("this equation has one real root:\n x = %f" , x1);

    }

    return 0;
}

void solver(float a , float b , float c , float* x1 , float* x2)
{
    float delta = (b * b) - (4 * a * c);

    if(delta > 0)
    {
        *x1 = (-b + sqrt(delta)) / (2 * a) ;
        *x2 = (-b - sqrt(delta)) / (2 * a) ;
    }

    else if (delta == 0)
        *x1 = *x2 = -b /(2 * a) ;

}